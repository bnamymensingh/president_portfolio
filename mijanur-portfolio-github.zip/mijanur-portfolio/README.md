# 🏥 MD. Mijanur Rahman – Official Portfolio

<div align="center">

![BNA](https://img.shields.io/badge/BNA-Mymensingh%20District-0d6e6e?style=for-the-badge)
![React](https://img.shields.io/badge/React-18-61DAFB?style=for-the-badge&logo=react)
![Vite](https://img.shields.io/badge/Vite-6-646CFF?style=for-the-badge&logo=vite)
![Netlify](https://img.shields.io/badge/Netlify-Ready-00C7B7?style=for-the-badge&logo=netlify)

**President, Bangladesh Nurses Association (BNA) – Mymensingh District Branch**

</div>

---

## 🇧🇩 বাংলা নির্দেশনা

### বৈশিষ্ট্যসমূহ
- 🌐 বাংলা ও ইংরেজি উভয় ভাষা
- 📱 মোবাইল রেসপন্সিভ ডিজাইন
- 📰 সংবাদ ও পোস্ট সেকশন
- 🔐 অ্যাডমিন ড্যাশবোর্ড
- 📞 যোগাযোগ ফর্ম
- ⚡ Vite + React (দ্রুত লোডিং)

---

## 🚀 GitHub → Netlify Deploy (সবচেয়ে সহজ পদ্ধতি)

### ধাপ ১ — এই ফাইলগুলো GitHub এ Upload করুন

1. [github.com](https://github.com) এ যান → Sign Up / Login
2. **"New repository"** ক্লিক করুন
3. Repository নাম দিন: `mijanur-portfolio`
4. **"uploading an existing file"** ক্লিক করুন
5. সব ফাইল Drag & Drop করুন → **"Commit changes"**

### ধাপ ২ — Netlify এ Connect করুন

1. [netlify.com](https://netlify.com) → Sign Up (GitHub দিয়ে)
2. **"Add new site" → "Import an existing project"**
3. **"Deploy with GitHub"** → Repository সিলেক্ট করুন
4. Build settings:
   - Build command: `npm run build`
   - Publish directory: `dist`
5. **"Deploy site"** ✅

> এখন থেকে GitHub এ যেকোনো পরিবর্তন করলে সাইট **স্বয়ংক্রিয়ভাবে** আপডেট হবে!

---

## 🔐 Admin Dashboard

| বিষয় | তথ্য |
|------|------|
| পাসওয়ার্ড | `BNA@2024` |
| পাসওয়ার্ড পরিবর্তন | `src/App.jsx` → `ADMIN_PASS` |

---

## ✏️ কাস্টমাইজেশন (`src/App.jsx`)

| বিষয় | খুঁজুন |
|------|--------|
| মোবাইল নম্বর | `+880-1XXXXXXXXX` |
| ইমেইল | `bna.mymensingh@gmail.com` |
| পাসওয়ার্ড | `BNA@2024` |

---

## 📁 Project Structure

```
mijanur-portfolio/
├── public/favicon.svg
├── src/
│   ├── App.jsx        ← সব পেজ এখানে
│   └── main.jsx
├── .github/workflows/deploy.yml
├── .gitignore
├── index.html
├── netlify.toml       ← Netlify config
├── package.json
└── vite.config.js
```

---

<div align="center">
Made with ❤️ for Bangladesh Nurses Association, Mymensingh
</div>
