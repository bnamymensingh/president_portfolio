import { useState, useEffect } from "react";

// ─── DATA ───────────────────────────────────────────────────────────────────
const ADMIN_PASS = "BNA@2024";

const content = {
  en: {
    name: "MD. MIJANUR RAHMAN",
    title: "President",
    org: "Bangladesh Nurses Association (BNA)",
    branch: "Mymensingh District Branch",
    tagline: "Dedicated to the advancement of nursing profession & healthcare in Bangladesh",
    nav: { home: "Home", about: "About", posts: "News & Posts", contact: "Contact", admin: "Admin" },
    about: {
      heading: "About",
      bio: `MD. Mijanur Rahman is a distinguished nursing professional and community leader serving as the President of Bangladesh Nurses Association (BNA), Mymensingh District Branch. With decades of experience in healthcare and nursing administration, he has been a steadfast advocate for the rights, welfare, and professional development of nurses across Mymensingh district.

His leadership has been instrumental in organizing training programs, community health initiatives, and policy advocacy efforts that have improved the lives of healthcare workers and patients alike. He remains committed to elevating the standards of nursing care throughout Bangladesh.`,
      role: "President, BNA – Mymensingh District Branch",
      experience: "Experience",
      expYears: "20+ Years",
      members: "Members Led",
      membersCount: "500+",
      programs: "Programs",
      programsCount: "50+",
    },
    posts: { heading: "News & Posts", empty: "No posts yet.", readMore: "Read More", postedOn: "Posted on", close: "Close" },
    contact: {
      heading: "Contact",
      address: "Bangladesh Nurses Association, Mymensingh District Branch, Mymensingh, Bangladesh",
      mobile: "Mobile",
      email: "Email",
      send: "Send Message",
      name: "Your Name",
      msg: "Your Message",
      emailLabel: "Your Email",
      successMsg: "Message sent successfully! We will contact you soon.",
    },
    admin: {
      heading: "Admin Dashboard",
      login: "Admin Login",
      password: "Password",
      enter: "Login",
      wrong: "Incorrect password. Please try again.",
      newPost: "Create New Post",
      titleLabel: "Post Title",
      bodyLabel: "Post Content",
      publish: "Publish Post",
      delete: "Delete",
      logout: "Logout",
      postsMgmt: "Manage Posts",
      noPostsYet: "No posts published yet.",
      published: "Post published successfully!",
      confirmDelete: "Are you sure you want to delete this post?",
    },
    footer: "© 2024 MD. Mijanur Rahman – President, Bangladesh Nurses Association, Mymensingh District Branch. All rights reserved.",
  },
  bn: {
    name: "মোঃ মিজানুর রহমান",
    title: "সভাপতি",
    org: "বাংলাদেশ নার্সেস অ্যাসোসিয়েশন (বিএনএ)",
    branch: "ময়মনসিংহ জেলা শাখা",
    tagline: "বাংলাদেশে নার্সিং পেশা ও স্বাস্থ্যসেবার উন্নয়নে নিবেদিত",
    nav: { home: "হোম", about: "পরিচিতি", posts: "সংবাদ ও পোস্ট", contact: "যোগাযোগ", admin: "অ্যাডমিন" },
    about: {
      heading: "পরিচিতি",
      bio: `মোঃ মিজানুর রহমান বাংলাদেশ নার্সেস অ্যাসোসিয়েশন (বিএনএ), ময়মনসিংহ জেলা শাখার সভাপতি হিসেবে দায়িত্ব পালনকারী একজন বিশিষ্ট নার্সিং পেশাদার ও সমাজনেতা। স্বাস্থ্যসেবা ও নার্সিং প্রশাসনে কয়েক দশকের অভিজ্ঞতায় তিনি ময়মনসিংহ জেলার নার্সদের অধিকার, কল্যাণ ও পেশাগত উন্নয়নে অক্লান্ত পরিশ্রম করে আসছেন।

তাঁর নেতৃত্বে প্রশিক্ষণ কার্যক্রম, সামাজিক স্বাস্থ্য উদ্যোগ এবং নীতি-সমর্থন কার্যক্রম পরিচালিত হয়েছে যা স্বাস্থ্যকর্মী ও রোগী উভয়ের জীবনমান উন্নত করেছে। তিনি সারা বাংলাদেশে নার্সিং সেবার মান উন্নয়নে দৃঢ়ভাবে প্রতিশ্রুতিবদ্ধ।`,
      role: "সভাপতি, বিএনএ – ময়মনসিংহ জেলা শাখা",
      experience: "অভিজ্ঞতা",
      expYears: "২০+ বছর",
      members: "সদস্য নেতৃত্ব",
      membersCount: "৫০০+",
      programs: "কার্যক্রম",
      programsCount: "৫০+",
    },
    posts: { heading: "সংবাদ ও পোস্ট", empty: "এখনও কোনো পোস্ট নেই।", readMore: "আরও পড়ুন", postedOn: "প্রকাশিত", close: "বন্ধ করুন" },
    contact: {
      heading: "যোগাযোগ",
      address: "বাংলাদেশ নার্সেস অ্যাসোসিয়েশন, ময়মনসিংহ জেলা শাখা, ময়মনসিংহ, বাংলাদেশ",
      mobile: "মোবাইল",
      email: "ইমেইল",
      send: "বার্তা পাঠান",
      name: "আপনার নাম",
      msg: "আপনার বার্তা",
      emailLabel: "আপনার ইমেইল",
      successMsg: "বার্তা সফলভাবে পাঠানো হয়েছে! আমরা শীঘ্রই যোগাযোগ করব।",
    },
    admin: {
      heading: "অ্যাডমিন ড্যাশবোর্ড",
      login: "অ্যাডমিন লগইন",
      password: "পাসওয়ার্ড",
      enter: "প্রবেশ করুন",
      wrong: "ভুল পাসওয়ার্ড। আবার চেষ্টা করুন।",
      newPost: "নতুন পোস্ট তৈরি করুন",
      titleLabel: "পোস্টের শিরোনাম",
      bodyLabel: "পোস্টের বিষয়বস্তু",
      publish: "পোস্ট প্রকাশ করুন",
      delete: "মুছুন",
      logout: "লগআউট",
      postsMgmt: "পোস্ট ব্যবস্থাপনা",
      noPostsYet: "এখনও কোনো পোস্ট প্রকাশিত হয়নি।",
      published: "পোস্ট সফলভাবে প্রকাশিত হয়েছে!",
      confirmDelete: "আপনি কি এই পোস্টটি মুছতে চান?",
    },
    footer: "© ২০২৪ মোঃ মিজানুর রহমান – সভাপতি, বাংলাদেশ নার্সেস অ্যাসোসিয়েশন, ময়মনসিংহ জেলা শাখা। সর্বস্বত্ব সংরক্ষিত।",
  },
};

const SAMPLE_POSTS = [
  {
    id: 1,
    titleEn: "Annual Nursing Conference 2024",
    titleBn: "বার্ষিক নার্সিং সম্মেলন ২০২৪",
    bodyEn: "The Bangladesh Nurses Association, Mymensingh District Branch, proudly announces its Annual Nursing Conference 2024. The event will focus on modern nursing practices, patient care improvements, and professional development opportunities for nurses across the district. All registered nurses are encouraged to attend and participate in the knowledge-sharing sessions.",
    bodyBn: "বাংলাদেশ নার্সেস অ্যাসোসিয়েশন, ময়মনসিংহ জেলা শাখা গর্বের সাথে বার্ষিক নার্সিং সম্মেলন ২০২৪ ঘোষণা করছে। এই অনুষ্ঠানে আধুনিক নার্সিং অনুশীলন, রোগীর সেবার উন্নতি এবং জেলার নার্সদের পেশাদার উন্নয়নের সুযোগগুলি নিয়ে আলোচনা করা হবে। সকল নিবন্ধিত নার্সদের জ্ঞান-ভাগাভাগি সেশনে অংশ নিতে উৎসাহিত করা হচ্ছে।",
    date: "2024-03-15",
  },
  {
    id: 2,
    titleEn: "Free Health Camp – Serving 300+ Patients",
    titleBn: "বিনামূল্যে স্বাস্থ্য শিবির – ৩০০+ রোগীকে সেবা",
    bodyEn: "BNA Mymensingh District Branch successfully organized a free health camp serving over 300 patients from underprivileged communities. The camp provided basic health checkups, blood pressure monitoring, diabetes screening, and essential medicines. This initiative reflects our commitment to accessible healthcare for all citizens of Mymensingh.",
    bodyBn: "বিএনএ ময়মনসিংহ জেলা শাখা সুবিধাবঞ্চিত সম্প্রদায়ের ৩০০ জনেরও বেশি রোগীকে সেবা প্রদানকারী একটি বিনামূল্যে স্বাস্থ্য শিবির সফলভাবে আয়োজন করেছে। এই শিবিরে মৌলিক স্বাস্থ্য পরীক্ষা, রক্তচাপ পর্যবেক্ষণ, ডায়াবেটিস স্ক্রিনিং এবং প্রয়োজনীয় ওষুধ সরবরাহ করা হয়েছে। এই উদ্যোগ ময়মনসিংহের সকল নাগরিকের জন্য সহজলভ্য স্বাস্থ্যসেবার প্রতি আমাদের প্রতিশ্রুতি প্রতিফলিত করে।",
    date: "2024-02-20",
  },
];

const styles = `
  @import url('https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;600;700;900&family=Source+Serif+4:ital,wght@0,300;0,400;0,600;1,400&family=Hind+Siliguri:wght@300;400;500;600;700&display=swap');

  *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

  :root {
    --navy: #0a1628;
    --navy2: #122040;
    --teal: #0d6e6e;
    --teal-light: #14b8a6;
    --gold: #c9a84c;
    --gold-light: #e8c97e;
    --cream: #faf7f2;
    --cream2: #f0ebe1;
    --text: #1e2a3a;
    --text-muted: #5a6b7e;
    --white: #ffffff;
    --radius: 12px;
    --shadow: 0 4px 24px rgba(10,22,40,0.10);
    --shadow-lg: 0 8px 48px rgba(10,22,40,0.16);
  }

  html { scroll-behavior: smooth; }
  body { font-family: 'Source Serif 4', Georgia, serif; background: var(--cream); color: var(--text); line-height: 1.7; }
  .bn-font { font-family: 'Hind Siliguri', sans-serif; }

  /* NAVBAR */
  .navbar {
    position: fixed; top: 0; left: 0; right: 0; z-index: 100;
    background: rgba(10,22,40,0.97); backdrop-filter: blur(12px);
    border-bottom: 1px solid rgba(201,168,76,0.2);
    padding: 0 24px; display: flex; align-items: center;
    justify-content: space-between; height: 64px;
  }
  .nav-brand { display: flex; flex-direction: column; cursor: pointer; }
  .nav-brand-name { color: var(--gold); font-size: 14px; font-weight: 700; font-family: 'Playfair Display', serif; line-height: 1.2; }
  .nav-brand-sub { color: rgba(255,255,255,0.5); font-size: 10px; letter-spacing: 1px; text-transform: uppercase; }
  .nav-links { display: flex; gap: 4px; align-items: center; }
  .nav-link {
    color: rgba(255,255,255,0.75); background: none; border: none; cursor: pointer;
    padding: 8px 14px; border-radius: 8px; font-family: 'Source Serif 4', serif;
    font-size: 14px; transition: all 0.2s; display: flex; align-items: center; gap: 6px;
  }
  .nav-link:hover, .nav-link.active { background: rgba(201,168,76,0.15); color: var(--gold-light); }
  .nav-actions { display: flex; gap: 8px; align-items: center; }
  .lang-btn {
    background: rgba(201,168,76,0.12); border: 1px solid rgba(201,168,76,0.3);
    color: var(--gold); border-radius: 8px; cursor: pointer;
    padding: 6px 14px; font-size: 12px; font-weight: 700; letter-spacing: 0.5px; transition: all 0.2s;
  }
  .lang-btn:hover { background: rgba(201,168,76,0.25); }
  .hamburger { display: none; background: none; border: none; cursor: pointer; padding: 4px; color: var(--gold); }

  @media (max-width: 768px) {
    .nav-links {
      display: none; position: fixed; top: 64px; left: 0; right: 0;
      background: rgba(10,22,40,0.98); flex-direction: column;
      padding: 16px; border-bottom: 1px solid rgba(201,168,76,0.2); gap: 4px;
    }
    .nav-links.open { display: flex; }
    .hamburger { display: block; }
    .nav-link { width: 100%; justify-content: flex-start; }
  }

  /* HERO */
  .hero {
    min-height: 100vh;
    background: linear-gradient(135deg, var(--navy) 0%, #0f2545 40%, #0a3b3b 100%);
    display: flex; align-items: center; justify-content: center;
    position: relative; overflow: hidden; padding: 80px 24px 48px;
  }
  .hero::before {
    content: ''; position: absolute; inset: 0;
    background: radial-gradient(ellipse at 70% 40%, rgba(13,110,110,0.25) 0%, transparent 60%),
                radial-gradient(ellipse at 20% 80%, rgba(201,168,76,0.12) 0%, transparent 50%);
  }
  .hero-pattern {
    position: absolute; inset: 0; opacity: 0.04;
    background-image: repeating-linear-gradient(45deg, var(--gold) 0, var(--gold) 1px, transparent 0, transparent 50%);
    background-size: 24px 24px;
  }
  .hero-content {
    position: relative; z-index: 1;
    display: flex; flex-direction: column; align-items: center; text-align: center;
    max-width: 700px; animation: fadeUp 0.8s ease;
  }
  @keyframes fadeUp { from { opacity:0; transform:translateY(30px); } to { opacity:1; transform:translateY(0); } }
  .hero-badge {
    background: rgba(201,168,76,0.15); border: 1px solid rgba(201,168,76,0.4);
    border-radius: 50px; padding: 6px 20px; color: var(--gold-light);
    font-size: 12px; letter-spacing: 2px; text-transform: uppercase; margin-bottom: 24px;
  }
  .hero-avatar {
    width: 140px; height: 140px; border-radius: 50%;
    background: linear-gradient(135deg, var(--teal) 0%, var(--navy2) 100%);
    border: 4px solid var(--gold); margin-bottom: 28px;
    display: flex; align-items: center; justify-content: center;
    font-size: 52px; font-family: 'Playfair Display', serif;
    color: var(--gold); font-weight: 700;
    box-shadow: 0 0 40px rgba(201,168,76,0.25), 0 8px 40px rgba(0,0,0,0.4);
  }
  .hero-name {
    font-family: 'Playfair Display', serif;
    font-size: clamp(26px, 5vw, 46px); font-weight: 900;
    color: var(--white); margin-bottom: 10px; line-height: 1.15;
  }
  .hero-title { font-size: clamp(14px, 2vw, 18px); color: var(--gold); margin-bottom: 4px; font-weight: 400; }
  .hero-org { font-size: clamp(13px, 1.8vw, 16px); color: rgba(255,255,255,0.7); margin-bottom: 4px; }
  .hero-branch { font-size: 13px; color: rgba(255,255,255,0.5); margin-bottom: 24px; }
  .hero-divider { width: 80px; height: 2px; margin: 0 auto 24px; background: linear-gradient(90deg, transparent, var(--gold), transparent); }
  .hero-tagline { font-size: clamp(13px, 1.8vw, 16px); color: rgba(255,255,255,0.65); max-width: 500px; font-style: italic; margin-bottom: 40px; }
  .hero-cta { display: flex; gap: 12px; flex-wrap: wrap; justify-content: center; }
  .btn-primary {
    background: linear-gradient(135deg, var(--gold) 0%, var(--gold-light) 100%);
    color: var(--navy); border: none; border-radius: 8px; padding: 13px 30px;
    font-size: 14px; font-weight: 700; cursor: pointer; transition: all 0.2s;
    font-family: 'Source Serif 4', serif;
  }
  .btn-primary:hover { transform: translateY(-2px); box-shadow: 0 8px 24px rgba(201,168,76,0.35); }
  .btn-outline {
    background: transparent; color: var(--white); border: 1px solid rgba(255,255,255,0.35);
    border-radius: 8px; padding: 13px 30px; font-size: 14px; cursor: pointer;
    transition: all 0.2s; font-family: 'Source Serif 4', serif;
  }
  .btn-outline:hover { border-color: var(--gold); color: var(--gold); }

  /* SECTIONS */
  .section { padding: 80px 24px; max-width: 1100px; margin: 0 auto; }
  .section-heading { font-family: 'Playfair Display', serif; font-size: clamp(26px, 4vw, 40px); font-weight: 700; color: var(--navy); margin-bottom: 8px; }
  .section-line { width: 60px; height: 3px; background: var(--gold); border-radius: 2px; margin-bottom: 40px; }
  .bna-tag {
    display: inline-block; background: rgba(13,110,110,0.1); color: var(--teal);
    border-radius: 6px; padding: 4px 12px; font-size: 12px; font-weight: 600;
    letter-spacing: 0.5px; margin-bottom: 12px;
  }

  /* ABOUT */
  .about-wrapper { display: grid; grid-template-columns: 1fr 1fr; gap: 48px; align-items: start; }
  @media (max-width: 768px) { .about-wrapper { grid-template-columns: 1fr; } }
  .about-bio { font-size: 15.5px; color: var(--text); line-height: 1.85; white-space: pre-line; }
  .about-role { margin-top: 16px; font-size: 14px; font-style: italic; color: var(--teal); font-weight: 600; }
  .stats-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 16px; }
  .stat-card {
    background: white; border-radius: var(--radius); padding: 24px 16px;
    text-align: center; box-shadow: var(--shadow); border-top: 3px solid var(--gold);
  }
  .stat-value { font-family: 'Playfair Display', serif; font-size: 30px; color: var(--navy); font-weight: 900; line-height: 1; }
  .stat-label { font-size: 12px; color: var(--text-muted); margin-top: 8px; letter-spacing: 0.5px; }
  .about-extra {
    margin-top: 24px; padding: 24px;
    background: linear-gradient(135deg, var(--navy) 0%, var(--navy2) 100%);
    border-radius: var(--radius); color: white;
  }
  .about-extra-title { font-family: 'Playfair Display', serif; font-size: 16px; color: var(--gold); margin-bottom: 10px; }
  .about-extra p { font-size: 13.5px; opacity: 0.8; line-height: 1.75; }

  /* POSTS */
  .posts-bg { background: var(--cream2); padding: 80px 0; }
  .posts-inner { max-width: 1100px; margin: 0 auto; padding: 0 24px; }
  .posts-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(320px, 1fr)); gap: 24px; }
  .post-card {
    background: white; border-radius: var(--radius); box-shadow: var(--shadow);
    overflow: hidden; transition: all 0.25s; cursor: pointer;
    border: 1px solid rgba(0,0,0,0.06);
  }
  .post-card:hover { transform: translateY(-4px); box-shadow: var(--shadow-lg); }
  .post-card-accent { height: 5px; background: linear-gradient(90deg, var(--navy), var(--teal)); }
  .post-card-body { padding: 24px; }
  .post-date { font-size: 12px; color: var(--text-muted); margin-bottom: 10px; display: flex; align-items: center; gap: 6px; }
  .post-title { font-family: 'Playfair Display', serif; font-size: 19px; color: var(--navy); margin-bottom: 12px; line-height: 1.35; font-weight: 700; }
  .post-excerpt { font-size: 14px; color: var(--text-muted); line-height: 1.7; }
  .post-read-more { display: inline-flex; align-items: center; gap: 4px; margin-top: 16px; font-size: 13px; color: var(--teal); font-weight: 600; cursor: pointer; background: none; border: none; font-family: inherit; }
  .empty-state { text-align: center; padding: 64px; color: var(--text-muted); font-size: 16px; }

  /* MODAL */
  .modal-overlay {
    position: fixed; inset: 0; z-index: 200;
    background: rgba(10,22,40,0.75); backdrop-filter: blur(4px);
    display: flex; align-items: center; justify-content: center; padding: 24px;
  }
  .modal-box {
    background: white; border-radius: 16px; max-width: 680px; width: 100%;
    max-height: 85vh; overflow-y: auto; padding: 40px;
    box-shadow: 0 24px 80px rgba(0,0,0,0.3); position: relative;
  }
  .modal-top { display: flex; justify-content: space-between; align-items: flex-start; gap: 16px; margin-bottom: 8px; }
  .modal-title { font-family: 'Playfair Display', serif; font-size: 26px; color: var(--navy); line-height: 1.3; flex: 1; }
  .modal-close {
    background: var(--cream2); border: none; border-radius: 8px;
    padding: 8px 16px; cursor: pointer; color: var(--navy); font-size: 13px; font-weight: 600;
    white-space: nowrap; flex-shrink: 0;
  }
  .modal-date { font-size: 13px; color: var(--text-muted); margin-bottom: 20px; }
  .modal-body { font-size: 15.5px; color: var(--text); line-height: 1.9; }

  /* CONTACT */
  .contact-wrapper { display: grid; grid-template-columns: 1fr 1fr; gap: 48px; }
  @media (max-width: 768px) { .contact-wrapper { grid-template-columns: 1fr; } }
  .contact-info { display: flex; flex-direction: column; gap: 16px; }
  .contact-item { display: flex; gap: 16px; align-items: flex-start; padding: 20px; background: white; border-radius: var(--radius); box-shadow: var(--shadow); }
  .contact-icon { width: 44px; height: 44px; border-radius: 10px; flex-shrink: 0; background: linear-gradient(135deg, var(--navy), var(--teal)); display: flex; align-items: center; justify-content: center; }
  .contact-label { font-size: 11px; color: var(--text-muted); text-transform: uppercase; letter-spacing: 1px; }
  .contact-value { font-size: 15px; color: var(--text); font-weight: 500; margin-top: 2px; }
  .contact-form { display: flex; flex-direction: column; gap: 14px; }
  .form-input, .form-textarea {
    border: 1.5px solid rgba(0,0,0,0.12); border-radius: 8px; padding: 12px 16px;
    font-size: 15px; width: 100%; font-family: 'Source Serif 4', serif;
    background: white; color: var(--text); transition: border-color 0.2s; outline: none;
  }
  .form-input:focus, .form-textarea:focus { border-color: var(--teal); }
  .form-textarea { resize: vertical; min-height: 130px; }
  .btn-submit {
    background: linear-gradient(135deg, var(--teal) 0%, #0a4f4f 100%);
    color: white; border: none; border-radius: 8px; padding: 14px 28px;
    font-size: 15px; font-weight: 600; cursor: pointer; transition: all 0.2s;
    font-family: 'Source Serif 4', serif;
  }
  .btn-submit:hover { transform: translateY(-2px); box-shadow: 0 8px 24px rgba(13,110,110,0.3); }
  .alert { padding: 12px 16px; border-radius: 8px; font-size: 14px; margin-top: 4px; }
  .alert-success { background: #d1fae5; color: #065f46; border: 1px solid #6ee7b7; }
  .alert-error { background: #fee2e2; color: #dc2626; border: 1px solid #fca5a5; }

  /* ADMIN */
  .admin-wrap { padding: 80px 24px; max-width: 900px; margin: 0 auto; }
  .admin-card { background: white; border-radius: 16px; padding: 40px; box-shadow: var(--shadow-lg); border-top: 4px solid var(--navy); }
  .admin-login-center { max-width: 400px; margin: 0 auto; text-align: center; }
  .admin-icon-circle { width: 80px; height: 80px; border-radius: 50%; background: linear-gradient(135deg, var(--navy), var(--teal)); display: flex; align-items: center; justify-content: center; margin: 0 auto 24px; }
  .admin-form { display: flex; flex-direction: column; gap: 14px; margin-top: 24px; }
  .admin-header { display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 32px; flex-wrap: wrap; gap: 12px; }
  .admin-subtitle { font-size: 13px; color: var(--text-muted); margin-top: 4px; }
  .new-post-form { background: var(--cream); border-radius: var(--radius); padding: 28px; margin-bottom: 32px; border: 1px dashed rgba(0,0,0,0.15); }
  .new-post-form h3 { font-family: 'Playfair Display', serif; font-size: 20px; margin-bottom: 16px; color: var(--navy); }
  .form-grid-2 { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; }
  @media (max-width: 600px) { .form-grid-2 { grid-template-columns: 1fr; } }
  .form-label { font-size: 12px; color: var(--text-muted); font-weight: 600; display: block; margin-bottom: 5px; letter-spacing: 0.3px; }
  .btn-success {
    background: linear-gradient(135deg, var(--teal), #0a4f4f); color: white;
    border: none; border-radius: 8px; padding: 12px 24px; font-size: 14px;
    font-weight: 600; cursor: pointer; transition: all 0.2s;
    display: inline-flex; align-items: center; gap: 8px; font-family: 'Source Serif 4', serif;
  }
  .btn-success:hover { transform: translateY(-1px); box-shadow: 0 4px 16px rgba(13,110,110,0.3); }
  .btn-danger {
    background: #fee2e2; color: #dc2626; border: 1px solid #fca5a5;
    border-radius: 8px; padding: 8px 14px; font-size: 12px; cursor: pointer;
    transition: all 0.2s; display: flex; align-items: center; gap: 4px; white-space: nowrap;
  }
  .btn-danger:hover { background: #dc2626; color: white; }
  .btn-logout {
    background: rgba(220,38,38,0.08); border: 1px solid rgba(220,38,38,0.25);
    color: #dc2626; border-radius: 8px; padding: 8px 16px; cursor: pointer;
    font-size: 13px; display: flex; align-items: center; gap: 6px; transition: all 0.2s;
  }
  .btn-logout:hover { background: rgba(220,38,38,0.15); }
  .post-manage-item {
    background: var(--cream2); border-radius: var(--radius); padding: 18px 20px;
    margin-bottom: 10px; display: flex; justify-content: space-between;
    align-items: center; gap: 12px; border: 1px solid rgba(0,0,0,0.07);
  }
  .post-manage-title { font-family: 'Playfair Display', serif; font-size: 15px; color: var(--navy); }
  .post-manage-date { font-size: 12px; color: var(--text-muted); margin-top: 2px; }
  .posts-mgmt-heading { font-family: 'Playfair Display', serif; font-size: 20px; color: var(--navy); margin-bottom: 16px; }
  .divider { border: none; border-top: 1px solid rgba(0,0,0,0.08); margin: 28px 0; }

  /* FOOTER */
  .footer { background: var(--navy); color: rgba(255,255,255,0.55); text-align: center; padding: 32px 24px; font-size: 13px; }
  .footer strong { color: var(--gold); }

  section[id] { scroll-margin-top: 64px; }
`;

const SVGIcon = ({ path, size = 18, color = "currentColor" }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d={path} />
  </svg>
);

const ICONS = {
  home: "M3 9l9-7 9 7v11a2 2 0 01-2 2H5a2 2 0 01-2-2z",
  about: "M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2M12 11a4 4 0 100-8 4 4 0 000 8z",
  posts: "M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8zM14 2v6h6M16 13H8M16 17H8M10 9H8",
  contact: "M22 16.92v3a2 2 0 01-2.18 2 19.79 19.79 0 01-8.63-3.07 19.5 19.5 0 01-6-6A19.79 19.79 0 012.12 4.18 2 2 0 014.11 2h3a2 2 0 012 1.72c.127.96.361 1.903.7 2.81a2 2 0 01-.45 2.11L8.09 9.91a16 16 0 006 6l1.27-1.27a2 2 0 012.11-.45c.907.339 1.85.573 2.81.7A2 2 0 0122 16.92z",
  admin: "M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z",
  menu: "M3 12h18M3 6h18M3 18h18",
  close: "M18 6L6 18M6 6l12 12",
  trash: "M3 6h18M8 6V4h8v2M19 6l-1 14a2 2 0 01-2 2H8a2 2 0 01-2-2L5 6",
  plus: "M12 5v14M5 12h14",
  phone: "M22 16.92v3a2 2 0 01-2.18 2 19.79 19.79 0 01-8.63-3.07 19.5 19.5 0 01-6-6A19.79 19.79 0 012.12 4.18 2 2 0 014.11 2h3a2 2 0 012 1.72c.127.96.361 1.903.7 2.81a2 2 0 01-.45 2.11L8.09 9.91a16 16 0 006 6l1.27-1.27a2 2 0 012.11-.45c.907.339 1.85.573 2.81.7A2 2 0 0122 16.92z",
  mail: "M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2zM22 6l-10 7L2 6",
  pin: "M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0118 0zM12 13a3 3 0 100-6 3 3 0 000 6z",
  cal: "M3 4h18v18H3zM3 9h18M8 2v4M16 2v4",
  logout: "M9 21H5a2 2 0 01-2-2V5a2 2 0 012-2h4M16 17l5-5-5-5M21 12H9",
  shield: "M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z",
};

export default function App() {
  const [lang, setLang] = useState("en");
  const [page, setPage] = useState("home");
  const [menuOpen, setMenuOpen] = useState(false);
  const [posts, setPosts] = useState(() => {
    try { const s = localStorage.getItem("bna_posts"); return s ? JSON.parse(s) : SAMPLE_POSTS; }
    catch { return SAMPLE_POSTS; }
  });
  const [selectedPost, setSelectedPost] = useState(null);
  const [adminLoggedIn, setAdminLoggedIn] = useState(false);
  const [adminPw, setAdminPw] = useState("");
  const [pwError, setPwError] = useState(false);
  const [newPost, setNewPost] = useState({ titleEn: "", titleBn: "", bodyEn: "", bodyBn: "" });
  const [postMsg, setPostMsg] = useState("");
  const [contactForm, setContactForm] = useState({ name: "", email: "", msg: "" });
  const [contactSuccess, setContactSuccess] = useState(false);

  const t = content[lang];
  const isBn = lang === "bn";

  const savePosts = (updated) => {
    setPosts(updated);
    try { localStorage.setItem("bna_posts", JSON.stringify(updated)); } catch {}
  };

  const handleLogin = () => {
    if (adminPw === ADMIN_PASS) { setAdminLoggedIn(true); setPwError(false); setAdminPw(""); }
    else { setPwError(true); }
  };

  const handlePublish = () => {
    if (!newPost.titleEn.trim() || !newPost.bodyEn.trim()) return;
    const p = {
      id: Date.now(),
      titleEn: newPost.titleEn,
      titleBn: newPost.titleBn || newPost.titleEn,
      bodyEn: newPost.bodyEn,
      bodyBn: newPost.bodyBn || newPost.bodyEn,
      date: new Date().toISOString().split("T")[0],
    };
    savePosts([p, ...posts]);
    setNewPost({ titleEn: "", titleBn: "", bodyEn: "", bodyBn: "" });
    setPostMsg(t.admin.published);
    setTimeout(() => setPostMsg(""), 3000);
  };

  const handleDelete = (id) => {
    if (window.confirm(t.admin.confirmDelete)) savePosts(posts.filter(p => p.id !== id));
  };

  const nav = (p) => { setPage(p); setMenuOpen(false); window.scrollTo(0, 0); };

  const navItems = [
    { key: "home", icon: ICONS.home },
    { key: "about", icon: ICONS.about },
    { key: "posts", icon: ICONS.posts },
    { key: "contact", icon: ICONS.contact },
    { key: "admin", icon: ICONS.admin },
  ];

  return (
    <>
      <style>{styles}</style>
      <div className={isBn ? "bn-font" : ""}>

        {/* ── NAVBAR ── */}
        <nav className="navbar">
          <div className="nav-brand" onClick={() => nav("home")}>
            <span className="nav-brand-name">{isBn ? "মোঃ মিজানুর রহমান" : "MD. MIJANUR RAHMAN"}</span>
            <span className="nav-brand-sub">{isBn ? "সভাপতি · বিএনএ ময়মনসিংহ" : "President · BNA Mymensingh"}</span>
          </div>
          <div className={`nav-links${menuOpen ? " open" : ""}`}>
            {navItems.map(({ key, icon }) => (
              <button key={key} className={`nav-link${page === key ? " active" : ""}`} onClick={() => nav(key)}>
                <SVGIcon path={icon} size={14} />{t.nav[key]}
              </button>
            ))}
          </div>
          <div className="nav-actions">
            <button className="lang-btn" onClick={() => setLang(l => l === "en" ? "bn" : "en")}>
              {lang === "en" ? "বাং" : "EN"}
            </button>
            <button className="hamburger" onClick={() => setMenuOpen(o => !o)}>
              <SVGIcon path={menuOpen ? ICONS.close : ICONS.menu} size={22} />
            </button>
          </div>
        </nav>

        {/* ── HOME ── */}
        {page === "home" && (
          <div className="hero">
            <div className="hero-pattern" />
            <div className="hero-content">
              <div className="hero-badge">
                {isBn ? "বাংলাদেশ নার্সেস অ্যাসোসিয়েশন · ময়মনসিংহ" : "Bangladesh Nurses Association · Mymensingh"}
              </div>
              <div className="hero-avatar">MR</div>
              <h1 className="hero-name">{t.name}</h1>
              <div className="hero-title">{t.title}</div>
              <div className="hero-org">{t.org}</div>
              <div className="hero-branch">{t.branch}</div>
              <div className="hero-divider" />
              <p className="hero-tagline">{t.tagline}</p>
              <div className="hero-cta">
                <button className="btn-primary" onClick={() => nav("about")}>
                  {isBn ? "পরিচিতি দেখুন" : "Learn More"}
                </button>
                <button className="btn-outline" onClick={() => nav("contact")}>
                  {isBn ? "যোগাযোগ করুন" : "Get in Touch"}
                </button>
              </div>
            </div>
          </div>
        )}

        {/* ── ABOUT ── */}
        {page === "about" && (
          <div style={{ paddingTop: 64 }}>
            <div className="section">
              <div className="bna-tag">{isBn ? "পরিচিতি" : "About"}</div>
              <h2 className="section-heading">{t.about.heading}</h2>
              <div className="section-line" />
              <div className="about-wrapper">
                <div>
                  <p className="about-bio">{t.about.bio}</p>
                  <p className="about-role">— {t.about.role}</p>
                </div>
                <div>
                  <div className="stats-grid">
                    {[
                      [t.about.expYears, t.about.experience],
                      [t.about.membersCount, t.about.members],
                      [t.about.programsCount, t.about.programs],
                    ].map(([val, label]) => (
                      <div className="stat-card" key={label}>
                        <div className="stat-value">{val}</div>
                        <div className="stat-label">{label}</div>
                      </div>
                    ))}
                  </div>
                  <div className="about-extra">
                    <div className="about-extra-title">{isBn ? "সংগঠন পরিচিতি" : "About BNA"}</div>
                    <p>
                      {isBn
                        ? "বাংলাদেশ নার্সেস অ্যাসোসিয়েশন দেশের নার্সিং পেশাদারদের সবচেয়ে বড় পেশাদার সংগঠন। ময়মনসিংহ জেলা শাখা স্থানীয় নার্সদের সেবা, প্রশিক্ষণ ও অধিকার রক্ষায় নিরলসভাবে কাজ করে যাচ্ছে।"
                        : "The Bangladesh Nurses Association is the largest professional organization for nursing professionals in the country. The Mymensingh District Branch tirelessly works to serve, train, and protect the rights of local nurses."
                      }
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* ── POSTS ── */}
        {page === "posts" && (
          <div style={{ paddingTop: 64 }}>
            <div className="posts-bg">
              <div className="posts-inner">
                <div className="bna-tag">{isBn ? "সংবাদ" : "News"}</div>
                <h2 className="section-heading">{t.posts.heading}</h2>
                <div className="section-line" />
                {posts.length === 0
                  ? <div className="empty-state">{t.posts.empty}</div>
                  : <div className="posts-grid">
                      {posts.map(post => (
                        <div className="post-card" key={post.id} onClick={() => setSelectedPost(post)}>
                          <div className="post-card-accent" />
                          <div className="post-card-body">
                            <div className="post-date">
                              <SVGIcon path={ICONS.cal} size={13} />
                              {t.posts.postedOn}: {post.date}
                            </div>
                            <div className="post-title">{isBn ? post.titleBn : post.titleEn}</div>
                            <div className="post-excerpt">
                              {(isBn ? post.bodyBn : post.bodyEn).slice(0, 160)}...
                            </div>
                            <button className="post-read-more">{t.posts.readMore} →</button>
                          </div>
                        </div>
                      ))}
                    </div>
                }
              </div>
            </div>
          </div>
        )}

        {/* ── CONTACT ── */}
        {page === "contact" && (
          <div style={{ paddingTop: 64 }}>
            <div className="section">
              <div className="bna-tag">{isBn ? "যোগাযোগ" : "Contact"}</div>
              <h2 className="section-heading">{t.contact.heading}</h2>
              <div className="section-line" />
              <div className="contact-wrapper">
                <div className="contact-info">
                  {[
                    { icon: ICONS.pin, label: isBn ? "ঠিকানা" : "Address", value: t.contact.address },
                    { icon: ICONS.phone, label: t.contact.mobile, value: "+880-1XXXXXXXXX" },
                    { icon: ICONS.mail, label: t.contact.email, value: "bna.mymensingh@gmail.com" },
                  ].map(({ icon, label, value }) => (
                    <div className="contact-item" key={label}>
                      <div className="contact-icon"><SVGIcon path={icon} size={20} color="white" /></div>
                      <div>
                        <div className="contact-label">{label}</div>
                        <div className="contact-value">{value}</div>
                      </div>
                    </div>
                  ))}
                </div>
                <div className="contact-form">
                  <input className="form-input" placeholder={t.contact.name} value={contactForm.name} onChange={e => setContactForm(f => ({ ...f, name: e.target.value }))} />
                  <input className="form-input" type="email" placeholder={t.contact.emailLabel} value={contactForm.email} onChange={e => setContactForm(f => ({ ...f, email: e.target.value }))} />
                  <textarea className="form-textarea" placeholder={t.contact.msg} value={contactForm.msg} onChange={e => setContactForm(f => ({ ...f, msg: e.target.value }))} />
                  <button className="btn-submit" onClick={() => { setContactSuccess(true); setContactForm({ name: "", email: "", msg: "" }); setTimeout(() => setContactSuccess(false), 4000); }}>
                    {t.contact.send}
                  </button>
                  {contactSuccess && <div className="alert alert-success">{t.contact.successMsg}</div>}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* ── ADMIN ── */}
        {page === "admin" && (
          <div style={{ paddingTop: 64 }}>
            <div className="admin-wrap">
              {!adminLoggedIn ? (
                <div className="admin-card">
                  <div className="admin-login-center">
                    <div className="admin-icon-circle">
                      <SVGIcon path={ICONS.shield} size={34} color="white" />
                    </div>
                    <h2 className="section-heading" style={{ textAlign: "center" }}>{t.admin.login}</h2>
                    <div className="admin-form">
                      <input
                        className="form-input" type="password"
                        placeholder={t.admin.password}
                        value={adminPw}
                        onChange={e => { setAdminPw(e.target.value); setPwError(false); }}
                        onKeyDown={e => e.key === "Enter" && handleLogin()}
                      />
                      {pwError && <div className="alert alert-error">{t.admin.wrong}</div>}
                      <button className="btn-submit" style={{ textAlign: "center" }} onClick={handleLogin}>
                        {t.admin.enter}
                      </button>
                    </div>
                    <p style={{ marginTop: 20, fontSize: 12, color: "var(--text-muted)", lineHeight: 1.6 }}>
                      {isBn ? "ডিফল্ট পাসওয়ার্ড: " : "Default password: "}<strong>BNA@2024</strong>
                    </p>
                  </div>
                </div>
              ) : (
                <div className="admin-card">
                  <div className="admin-header">
                    <div>
                      <h2 className="section-heading">{t.admin.heading}</h2>
                      <div className="admin-subtitle">{isBn ? "পোস্ট পরিচালনা ও প্রকাশনা" : "Manage and publish posts"}</div>
                    </div>
                    <button className="btn-logout" onClick={() => setAdminLoggedIn(false)}>
                      <SVGIcon path={ICONS.logout} size={14} />{t.admin.logout}
                    </button>
                  </div>

                  {/* NEW POST */}
                  <div className="new-post-form">
                    <h3>{t.admin.newPost}</h3>
                    <div className="form-grid-2">
                      <div>
                        <label className="form-label">Title (English) *</label>
                        <input className="form-input" placeholder="Post title in English" value={newPost.titleEn} onChange={e => setNewPost(p => ({ ...p, titleEn: e.target.value }))} />
                      </div>
                      <div>
                        <label className="form-label">শিরোনাম (বাংলা)</label>
                        <input className="form-input" placeholder="পোস্টের শিরোনাম বাংলায়" value={newPost.titleBn} onChange={e => setNewPost(p => ({ ...p, titleBn: e.target.value }))} />
                      </div>
                    </div>
                    <div style={{ marginTop: 12 }}>
                      <label className="form-label">Content (English) *</label>
                      <textarea className="form-textarea" placeholder="Write post content in English..." value={newPost.bodyEn} onChange={e => setNewPost(p => ({ ...p, bodyEn: e.target.value }))} />
                    </div>
                    <div style={{ marginTop: 12 }}>
                      <label className="form-label">বিষয়বস্তু (বাংলা)</label>
                      <textarea className="form-textarea" placeholder="বাংলায় পোস্টের বিষয়বস্তু লিখুন..." value={newPost.bodyBn} onChange={e => setNewPost(p => ({ ...p, bodyBn: e.target.value }))} />
                    </div>
                    <div style={{ marginTop: 16, display: "flex", alignItems: "center", gap: 16, flexWrap: "wrap" }}>
                      <button className="btn-success" onClick={handlePublish}>
                        <SVGIcon path={ICONS.plus} size={16} />{t.admin.publish}
                      </button>
                      {postMsg && <div className="alert alert-success" style={{ margin: 0 }}>{postMsg}</div>}
                    </div>
                  </div>

                  <hr className="divider" />

                  {/* POSTS LIST */}
                  <div className="posts-mgmt-heading">{t.admin.postsMgmt} ({posts.length})</div>
                  {posts.length === 0
                    ? <div className="empty-state" style={{ padding: 32 }}>{t.admin.noPostsYet}</div>
                    : posts.map(post => (
                        <div className="post-manage-item" key={post.id}>
                          <div>
                            <div className="post-manage-title">{post.titleEn}</div>
                            {post.titleBn !== post.titleEn && (
                              <div style={{ fontSize: 13, color: "var(--teal)", marginTop: 2 }}>{post.titleBn}</div>
                            )}
                            <div className="post-manage-date">{post.date}</div>
                          </div>
                          <button className="btn-danger" onClick={() => handleDelete(post.id)}>
                            <SVGIcon path={ICONS.trash} size={13} />{t.admin.delete}
                          </button>
                        </div>
                      ))
                  }
                </div>
              )}
            </div>
          </div>
        )}

        {/* ── POST MODAL ── */}
        {selectedPost && (
          <div className="modal-overlay" onClick={() => setSelectedPost(null)}>
            <div className="modal-box" onClick={e => e.stopPropagation()}>
              <div className="modal-top">
                <div className="modal-title">{isBn ? selectedPost.titleBn : selectedPost.titleEn}</div>
                <button className="modal-close" onClick={() => setSelectedPost(null)}>{t.posts.close} ✕</button>
              </div>
              <div className="modal-date">
                <SVGIcon path={ICONS.cal} size={13} /> {t.posts.postedOn}: {selectedPost.date}
              </div>
              <div className="modal-body">{isBn ? selectedPost.bodyBn : selectedPost.bodyEn}</div>
            </div>
          </div>
        )}

        {/* ── FOOTER ── */}
        <footer className="footer">
          <div style={{ marginBottom: 6 }}>
            <strong>{isBn ? "মোঃ মিজানুর রহমান" : "MD. MIJANUR RAHMAN"}</strong>
          </div>
          <div>{t.footer}</div>
        </footer>

      </div>
    </>
  );
}
